<div>
    <div class="container-fluid">
        <div class="table-header" style="height:120px;">
            <div class="fs-3 mt-4 mb-2 fw-semibold">
                {{ $title }}s
            </div>
            <livewire:admin.BreadCrumb.BreadCrumb/>
        </div>
        <div class="d-flex justify-content-between my-2 gap-2 row">


        
        </div>
    </div>
</div>


