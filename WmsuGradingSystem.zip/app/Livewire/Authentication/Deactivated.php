<?php

namespace App\Livewire\Authentication;

use Livewire\Component;

class Deactivated extends Component
{
    public function render()
    {
        return view('livewire.authentication.deactivated');
    }
}
