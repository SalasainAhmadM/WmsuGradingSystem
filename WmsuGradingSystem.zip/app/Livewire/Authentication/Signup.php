<?php

namespace App\Livewire\Authentication;

use Livewire\Component;

class Signup extends Component
{
    public function render()
    {
        return view('livewire.authentication.signup');
    }
}
