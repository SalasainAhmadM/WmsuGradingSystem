<?php

namespace App\Livewire\Authentication;

use Livewire\Component;

class ForgotPassword extends Component
{
    public function render()
    {
        return view('livewire.authentication.forgot-password');
    }
}
