<?php

namespace App\Livewire\Admin\Evaluation;

use Livewire\Component;

class EvaluationFinalGradingLists extends Component
{
    public function render()
    {
        return view('livewire.admin.evaluation.evaluation-final-grading-lists');
    }
}
