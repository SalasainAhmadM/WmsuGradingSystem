<?php

namespace App\Livewire\Admin\BreadCrumb;

use Livewire\Component;

class BreadCrumb extends Component
{
    public function render()
    {
        return view('livewire.admin.bread-crumb.bread-crumb');
    }
}
