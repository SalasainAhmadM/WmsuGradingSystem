<?php

namespace App\Livewire\Admin\Curriculum;

use Livewire\Component;

class AddCurriculum extends Component
{
    public function render()
    {
        return view('livewire.admin.curriculum.add-curriculum');
    }
}
