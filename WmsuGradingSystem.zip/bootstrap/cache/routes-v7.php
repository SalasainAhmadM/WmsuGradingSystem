<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/livewire/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MYjhkhQ64DFvUemH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.min.js.map' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6P8tcInVKCTPv3fi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/upload-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.upload-file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bNyFoQeK3GDyLBl1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ak0OliuQEWU7SI9d',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/signup' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'signup',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/account-deactivated' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'deactivated',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/colleges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'college-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/colleges/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'college-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/departments/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/school-years' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'school-year-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/school-years/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'school-year-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/semesters' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/semesters/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/year-levels' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year-level-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/year-levels/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year-level-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/subjects' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'subject-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/subjects/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'subject-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/students' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/students/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/rooms' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'room-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/rooms/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'room-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/admins' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/admins/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/academic/faculty' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/academic/faculty/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/academic/faculty-types' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-type-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/academic/faculty-types/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-type-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/academic/ranks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rank-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/academic/ranks/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rank-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/academic/designations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'designation-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/academic/designations/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'designation-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/curriculums' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'curriculum-lists-college',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/faculty-and-scheduling' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scheduling-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/schedules' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'schedule-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/schedules/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'schedule-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/grade-equivalent' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'grade-equivalent-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/grade-equivalent/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'grade-equivalent-add',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/faculty' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-schedule-default',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/faculty/my-schedules' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-schedule-school-years-lists',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/student' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-grades-default',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/student/my-grades' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-grades',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/student/my-schedules' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-schedules',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/attendance-dates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'attendance-dates',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/attendance-dates/remove' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'attendance-dates-remove',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/attendance-dates/add' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'attendance-dates-add',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/livewire/preview\\-file/([^/]++)(*:39)|/admin/(?|c(?|olleges/(?|edit\\-([^/]++)(*:85)|delete\\-([^/]++)(*:108)|activate\\-([^/]++)(*:134)|view\\-([^/]++)(*:156))|urriculums/([^/]++)(?|/([^/]++)(?|/([^/]++)(*:208)|(*:216))|(*:225)))|departments(?|(?:\\-([^/]++))?(*:264)|(*:272)|/(?|edit\\-([^/]++)(*:298)|delete\\-([^/]++)(*:322)|activate\\-([^/]++)(*:348)|view\\-([^/]++)(*:370)))|s(?|ch(?|ool\\-years/(?|edit\\-([^/]++)(*:417)|delete\\-([^/]++)(*:441)|view\\-([^/]++)(*:463))|edules/(?|edit\\-([^/]++)(*:496)|delete\\-([^/]++)(*:520)|activate\\-([^/]++)(*:546)|view\\-([^/]++)(*:568)))|emesters/(?|edit\\-([^/]++)(*:604)|delete\\-([^/]++)(*:628)|activate\\-([^/]++)(*:654)|view\\-([^/]++)(*:676))|ubjects/(?|edit\\-([^/]++)(*:710)|delete\\-([^/]++)(*:734)|activate\\-([^/]++)(*:760)|view\\-([^/]++)(*:782))|tudents/(?|view\\-([^/]++)(?|/schedule\\-([^/]++)(*:838)|(*:846))|edit\\-([^/]++)(*:869)|delete\\-([^/]++)(*:893)|activate\\-([^/]++)(*:919)))|year\\-levels/(?|edit\\-([^/]++)(*:959)|delete\\-([^/]++)(*:983)|activate\\-([^/]++)(*:1009)|view\\-([^/]++)(*:1032))|rooms/(?|edit\\-([^/]++)(*:1065)|delete\\-([^/]++)(*:1090)|activate\\-([^/]++)(*:1117)|view\\-([^/]++)(*:1140))|a(?|dmins/(?|edit\\-([^/]++)(*:1177)|delete\\-([^/]++)(*:1202)|view\\-([^/]++)(*:1225))|cademic/(?|faculty(?|/(?|edit\\-([^/]++)(*:1274)|delete\\-([^/]++)(*:1299)|activate\\-([^/]++)(*:1326)|view\\-([^/]++)(*:1349))|\\-types/(?|edit\\-([^/]++)(*:1384)|delete\\-([^/]++)(*:1409)|activate\\-([^/]++)(*:1436)|view\\-([^/]++)(*:1459)))|ranks/(?|edit\\-([^/]++)(*:1493)|delete\\-([^/]++)(*:1518)|activate\\-([^/]++)(*:1545)|view\\-([^/]++)(*:1568))|designations/(?|edit\\-([^/]++)(*:1608)|delete\\-([^/]++)(*:1633)|activate\\-([^/]++)(*:1660)|view\\-([^/]++)(*:1683))))|faculty\\-and\\-scheduling/(?|e(?|valuation\\-(?|([^/]++)/attendance\\-([^/]++)(*:1770)|final\\-grading\\-([^/]++)(*:1803)|([^/]++)(*:1820))|nrolled\\-([^/]++)(?|(*:1850)|/(?|a(?|dd(*:1869)|ctivate\\-([^/]++)(*:1895))|edit\\-([^/]++)(*:1919)|delete\\-([^/]++)(*:1944)|view\\-([^/]++)(*:1967))))|([^/]++)(?|/([^/]++)(?|/([^/]++)(?|/([^/]++)/([^/]++)(*:2032)|(*:2041))|(*:2051))|(*:2061)))|grade\\-equivalent/(?|edit\\-([^/]++)(*:2107)|delete\\-([^/]++)(*:2132)|activate\\-([^/]++)(*:2159)|view\\-([^/]++)(*:2182)))|/faculty/(?|my\\-schedules/([^/]++)(?|(*:2230)|/([^/]++)(?|/e(?|nrolled\\-students\\-([^/]++)(*:2283)|valuation\\-(?|final\\-grading\\-([^/]++)(*:2330)|([^/]++)(?|/attendance\\-([^/]++)(*:2371)|(*:2380))))|(*:2392)))|rooms/view\\-([^/]++)(*:2423)|s(?|ubjects/view\\-([^/]++)(*:2458)|emesters/view\\-([^/]++)(*:2490)|chool\\-years/view\\-([^/]++)(*:2526)|tudents/view\\-([^/]++)(?|/schedule\\-([^/]++)(*:2579)|(*:2588)))|year\\-levels/view\\-([^/]++)(*:2626)|departments/view\\-([^/]++)(*:2661)|colleges/view\\-([^/]++)(*:2693)|academic/(?|designations/view\\-([^/]++)(*:2741)|ranks/view\\-([^/]++)(*:2770)|faculty(?|\\-types/view\\-([^/]++)(*:2811)|/view\\-([^/]++)(*:2835))))|/st(?|udent/(?|my\\-grades/view\\-([^/]++)/schedule\\-([^/]++)(*:2906)|rooms/view\\-([^/]++)(*:2935)|subjects/view\\-([^/]++)(*:2967)|faculty/view\\-([^/]++)(*:2998))|orage/(.*)(*:3018)))/?$}sDu',
    ),
    3 => 
    array (
      39 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.preview-file',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      85 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'college-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      108 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'college-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      134 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'college-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      156 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'college-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      208 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'curriculum-lists-enrolled',
          ),
          1 => 
          array (
            0 => 'college',
            1 => 'department',
            2 => 'curriculum_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      216 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'curriculum-lists',
          ),
          1 => 
          array (
            0 => 'college',
            1 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      225 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'curriculum-lists-departments',
          ),
          1 => 
          array (
            0 => 'college',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      264 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department-lists-college',
            'id' => NULL,
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      272 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department-lists',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      298 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      322 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      348 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      370 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'department-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      417 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'school-year-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      441 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'school-year-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      463 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'school-year-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      496 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'schedule-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      520 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'schedule-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      546 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'schedule-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      568 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'schedule-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      604 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      628 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      654 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      676 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'semester-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      710 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'subject-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      734 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'subject-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      760 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'subject-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      782 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'subject-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      838 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-student-grade-components',
          ),
          1 => 
          array (
            0 => 'student_id',
            1 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      846 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      869 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      893 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      919 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      959 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year-level-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      983 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year-level-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1009 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year-level-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1032 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'year-level-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1065 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'room-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1090 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'room-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1117 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'room-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1140 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'room-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1177 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1202 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1225 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1274 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1299 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1326 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1349 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1384 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-type-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1409 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-type-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1436 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-type-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1459 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-type-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1493 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rank-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1518 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rank-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1545 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rank-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1568 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rank-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1608 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'designation-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'designation-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1660 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'designation-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1683 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'designation-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1770 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'attendance-lists',
          ),
          1 => 
          array (
            0 => 'schedule_id',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1803 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'evaluation-lists-final-grading',
          ),
          1 => 
          array (
            0 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1820 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'evaluation-lists',
          ),
          1 => 
          array (
            0 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1850 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'enrolled-student-lists',
          ),
          1 => 
          array (
            0 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1869 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'enrolled-student-add',
          ),
          1 => 
          array (
            0 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1895 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'enrolled-student-activate',
          ),
          1 => 
          array (
            0 => 'schedule_id',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1919 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'enrolled-student-edit',
          ),
          1 => 
          array (
            0 => 'schedule_id',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1944 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'enrolled-student-delete',
          ),
          1 => 
          array (
            0 => 'schedule_id',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1967 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'enrolled-student-view',
          ),
          1 => 
          array (
            0 => 'schedule_id',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2032 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'curriculum-subjects-list',
          ),
          1 => 
          array (
            0 => 'school_year',
            1 => 'college',
            2 => 'department',
            3 => 'year_level',
            4 => 'semester',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2041 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scheduling-lists-enrolled',
          ),
          1 => 
          array (
            0 => 'school_year',
            1 => 'college',
            2 => 'department',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2051 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scheduling-lists-departments',
          ),
          1 => 
          array (
            0 => 'school_year',
            1 => 'college',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2061 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'scheduling-lists-college',
          ),
          1 => 
          array (
            0 => 'school_year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2107 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'grade-equivalent-edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'grade-equivalent-delete',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2159 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'grade-equivalent-activate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2182 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'grade-equivalent-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2230 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-schedule-semesters-lists',
          ),
          1 => 
          array (
            0 => 'school_year',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2283 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-enrolled-students',
          ),
          1 => 
          array (
            0 => 'school_year',
            1 => 'semester',
            2 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2330 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-evaluation-lists-final-grading',
          ),
          1 => 
          array (
            0 => 'school_year',
            1 => 'semester',
            2 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2371 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-attendance-lists',
          ),
          1 => 
          array (
            0 => 'school_year',
            1 => 'semester',
            2 => 'schedule_id',
            3 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2380 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-evaluation-lists',
          ),
          1 => 
          array (
            0 => 'school_year',
            1 => 'semester',
            2 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2392 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-schedule-lists',
          ),
          1 => 
          array (
            0 => 'school_year',
            1 => 'semester',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2423 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-room-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2458 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-subject-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-semester-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2526 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-school-year-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2579 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-student-grade-components',
          ),
          1 => 
          array (
            0 => 'student_id',
            1 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2588 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-student-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2626 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-year-level-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2661 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-department-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2693 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'my-college-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2741 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-designation-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2770 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-rank-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2811 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-faculty-type-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2835 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'faculty-faculty-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2906 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-grade-components',
          ),
          1 => 
          array (
            0 => 'student_id',
            1 => 'schedule_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2935 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-room-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2967 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-subject-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2998 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'student-faculty-view',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3018 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'livewire.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/update',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\HandleRequests\\HandleRequests@handleUpdate',
        'controller' => 'Livewire\\Mechanisms\\HandleRequests\\HandleRequests@handleUpdate',
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'livewire.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MYjhkhQ64DFvUemH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@returnJavaScriptAsFile',
        'controller' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@returnJavaScriptAsFile',
        'as' => 'generated::MYjhkhQ64DFvUemH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6P8tcInVKCTPv3fi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.min.js.map',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@maps',
        'controller' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@maps',
        'as' => 'generated::6P8tcInVKCTPv3fi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.upload-file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/upload-file',
      'action' => 
      array (
        'uses' => 'Livewire\\Features\\SupportFileUploads\\FileUploadController@handle',
        'controller' => 'Livewire\\Features\\SupportFileUploads\\FileUploadController@handle',
        'as' => 'livewire.upload-file',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.preview-file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/preview-file/{filename}',
      'action' => 
      array (
        'uses' => 'Livewire\\Features\\SupportFileUploads\\FilePreviewController@handle',
        'controller' => 'Livewire\\Features\\SupportFileUploads\\FilePreviewController@handle',
        'as' => 'livewire.preview-file',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bNyFoQeK3GDyLBl1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:855:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'/home/u701207055/domains/wmsugradingsystem.online/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000007240000000000000000";}}',
        'as' => 'generated::bNyFoQeK3GDyLBl1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ak0OliuQEWU7SI9d' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsUnauthenticated',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:61:"function () {
       return \\redirect(\\route(\'login\'));
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000072a0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ak0OliuQEWU7SI9d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsUnauthenticated',
        ),
        'uses' => 'App\\Livewire\\Authentication\\Login@__invoke',
        'controller' => 'App\\Livewire\\Authentication\\Login',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'signup' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'signup',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsUnauthenticated',
        ),
        'uses' => 'App\\Livewire\\Authentication\\Signup@__invoke',
        'controller' => 'App\\Livewire\\Authentication\\Signup',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'signup',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'deactivated' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'account-deactivated',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
        ),
        'uses' => 'App\\Livewire\\Authentication\\Deactivated@__invoke',
        'controller' => 'App\\Livewire\\Authentication\\Deactivated',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'deactivated',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
        ),
        'uses' => 'App\\Livewire\\Authentication\\Logout@__invoke',
        'controller' => 'App\\Livewire\\Authentication\\Logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:74:"function (){
            return \\redirect (\\route(\'dashboard\'));
        }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007320000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin-dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:89:"function(){
           return \\redirect(\\route(\'curriculum-lists-college\'));
           }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007360000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'admin/dashboard',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'college-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\College\\CollegeLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\College\\CollegeLists',
        'namespace' => NULL,
        'prefix' => 'admin/colleges',
        'where' => 
        array (
        ),
        'as' => 'college-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'college-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/colleges/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\College\\AddCollege@__invoke',
        'controller' => 'App\\Livewire\\Admin\\College\\AddCollege',
        'namespace' => NULL,
        'prefix' => 'admin/colleges',
        'where' => 
        array (
        ),
        'as' => 'college-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'college-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/colleges/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\College\\EditCollege@__invoke',
        'controller' => 'App\\Livewire\\Admin\\College\\EditCollege',
        'namespace' => NULL,
        'prefix' => 'admin/colleges',
        'where' => 
        array (
        ),
        'as' => 'college-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'college-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/colleges/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\College\\DeleteCollege@__invoke',
        'controller' => 'App\\Livewire\\Admin\\College\\DeleteCollege',
        'namespace' => NULL,
        'prefix' => 'admin/colleges',
        'where' => 
        array (
        ),
        'as' => 'college-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'college-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/colleges/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\College\\ActivateCollege@__invoke',
        'controller' => 'App\\Livewire\\Admin\\College\\ActivateCollege',
        'namespace' => NULL,
        'prefix' => 'admin/colleges',
        'where' => 
        array (
        ),
        'as' => 'college-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'college-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/colleges/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\College\\ViewCollege@__invoke',
        'controller' => 'App\\Livewire\\Admin\\College\\ViewCollege',
        'namespace' => NULL,
        'prefix' => 'admin/colleges',
        'where' => 
        array (
        ),
        'as' => 'college-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department-lists-college' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/departments-{id?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Department\\DepartmentLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Department\\DepartmentLists',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'department-lists-college',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/departments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Department\\DepartmentLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Department\\DepartmentLists',
        'namespace' => NULL,
        'prefix' => 'admin/departments',
        'where' => 
        array (
        ),
        'as' => 'department-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/departments/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Department\\AddDepartment@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Department\\AddDepartment',
        'namespace' => NULL,
        'prefix' => 'admin/departments',
        'where' => 
        array (
        ),
        'as' => 'department-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/departments/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Department\\EditDepartment@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Department\\EditDepartment',
        'namespace' => NULL,
        'prefix' => 'admin/departments',
        'where' => 
        array (
        ),
        'as' => 'department-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/departments/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Department\\DeleteDepartment@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Department\\DeleteDepartment',
        'namespace' => NULL,
        'prefix' => 'admin/departments',
        'where' => 
        array (
        ),
        'as' => 'department-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/departments/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Department\\ActivateDepartment@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Department\\ActivateDepartment',
        'namespace' => NULL,
        'prefix' => 'admin/departments',
        'where' => 
        array (
        ),
        'as' => 'department-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'department-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/departments/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Department\\ViewDepartment@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Department\\ViewDepartment',
        'namespace' => NULL,
        'prefix' => 'admin/departments',
        'where' => 
        array (
        ),
        'as' => 'department-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'school-year-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/school-years',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\SchoolYear\\SchoolYearLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\SchoolYear\\SchoolYearLists',
        'namespace' => NULL,
        'prefix' => 'admin/school-years',
        'where' => 
        array (
        ),
        'as' => 'school-year-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'school-year-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/school-years/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\SchoolYear\\AddSchoolYear@__invoke',
        'controller' => 'App\\Livewire\\Admin\\SchoolYear\\AddSchoolYear',
        'namespace' => NULL,
        'prefix' => 'admin/school-years',
        'where' => 
        array (
        ),
        'as' => 'school-year-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'school-year-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/school-years/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\SchoolYear\\EditSchoolYear@__invoke',
        'controller' => 'App\\Livewire\\Admin\\SchoolYear\\EditSchoolYear',
        'namespace' => NULL,
        'prefix' => 'admin/school-years',
        'where' => 
        array (
        ),
        'as' => 'school-year-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'school-year-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/school-years/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\SchoolYear\\DeleteSchoolYear@__invoke',
        'controller' => 'App\\Livewire\\Admin\\SchoolYear\\DeleteSchoolYear',
        'namespace' => NULL,
        'prefix' => 'admin/school-years',
        'where' => 
        array (
        ),
        'as' => 'school-year-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'school-year-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/school-years/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\SchoolYear\\ViewSchoolYear@__invoke',
        'controller' => 'App\\Livewire\\Admin\\SchoolYear\\ViewSchoolYear',
        'namespace' => NULL,
        'prefix' => 'admin/school-years',
        'where' => 
        array (
        ),
        'as' => 'school-year-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/semesters',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Semester\\SemesterLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Semester\\SemesterLists',
        'namespace' => NULL,
        'prefix' => 'admin/semesters',
        'where' => 
        array (
        ),
        'as' => 'semester-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/semesters/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Semester\\AddSemester@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Semester\\AddSemester',
        'namespace' => NULL,
        'prefix' => 'admin/semesters',
        'where' => 
        array (
        ),
        'as' => 'semester-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/semesters/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Semester\\EditSemester@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Semester\\EditSemester',
        'namespace' => NULL,
        'prefix' => 'admin/semesters',
        'where' => 
        array (
        ),
        'as' => 'semester-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/semesters/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Semester\\DeleteSemester@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Semester\\DeleteSemester',
        'namespace' => NULL,
        'prefix' => 'admin/semesters',
        'where' => 
        array (
        ),
        'as' => 'semester-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/semesters/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Semester\\ActivateSemester@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Semester\\ActivateSemester',
        'namespace' => NULL,
        'prefix' => 'admin/semesters',
        'where' => 
        array (
        ),
        'as' => 'semester-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'semester-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/semesters/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Semester\\ViewSemester@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Semester\\ViewSemester',
        'namespace' => NULL,
        'prefix' => 'admin/semesters',
        'where' => 
        array (
        ),
        'as' => 'semester-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year-level-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year-levels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\YearLevel\\YearLevelLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\YearLevel\\YearLevelLists',
        'namespace' => NULL,
        'prefix' => 'admin/year-levels',
        'where' => 
        array (
        ),
        'as' => 'year-level-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year-level-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year-levels/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\YearLevel\\AddYearLevel@__invoke',
        'controller' => 'App\\Livewire\\Admin\\YearLevel\\AddYearLevel',
        'namespace' => NULL,
        'prefix' => 'admin/year-levels',
        'where' => 
        array (
        ),
        'as' => 'year-level-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year-level-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year-levels/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\YearLevel\\EditYearLevel@__invoke',
        'controller' => 'App\\Livewire\\Admin\\YearLevel\\EditYearLevel',
        'namespace' => NULL,
        'prefix' => 'admin/year-levels',
        'where' => 
        array (
        ),
        'as' => 'year-level-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year-level-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year-levels/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\YearLevel\\DeleteYearLevel@__invoke',
        'controller' => 'App\\Livewire\\Admin\\YearLevel\\DeleteYearLevel',
        'namespace' => NULL,
        'prefix' => 'admin/year-levels',
        'where' => 
        array (
        ),
        'as' => 'year-level-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year-level-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year-levels/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\YearLevel\\ActivateYearLevel@__invoke',
        'controller' => 'App\\Livewire\\Admin\\YearLevel\\ActivateYearLevel',
        'namespace' => NULL,
        'prefix' => 'admin/year-levels',
        'where' => 
        array (
        ),
        'as' => 'year-level-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'year-level-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/year-levels/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\YearLevel\\ViewYearLevel@__invoke',
        'controller' => 'App\\Livewire\\Admin\\YearLevel\\ViewYearLevel',
        'namespace' => NULL,
        'prefix' => 'admin/year-levels',
        'where' => 
        array (
        ),
        'as' => 'year-level-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'subject-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/subjects',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Subjects\\SubjectLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Subjects\\SubjectLists',
        'namespace' => NULL,
        'prefix' => 'admin/subjects',
        'where' => 
        array (
        ),
        'as' => 'subject-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'subject-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/subjects/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Subjects\\AddSubject@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Subjects\\AddSubject',
        'namespace' => NULL,
        'prefix' => 'admin/subjects',
        'where' => 
        array (
        ),
        'as' => 'subject-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'subject-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/subjects/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Subjects\\EditSubject@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Subjects\\EditSubject',
        'namespace' => NULL,
        'prefix' => 'admin/subjects',
        'where' => 
        array (
        ),
        'as' => 'subject-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'subject-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/subjects/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Subjects\\DeleteSubject@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Subjects\\DeleteSubject',
        'namespace' => NULL,
        'prefix' => 'admin/subjects',
        'where' => 
        array (
        ),
        'as' => 'subject-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'subject-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/subjects/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Subjects\\ActivateSubject@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Subjects\\ActivateSubject',
        'namespace' => NULL,
        'prefix' => 'admin/subjects',
        'where' => 
        array (
        ),
        'as' => 'subject-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'subject-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/subjects/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Subjects\\ViewSubject@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Subjects\\ViewSubject',
        'namespace' => NULL,
        'prefix' => 'admin/subjects',
        'where' => 
        array (
        ),
        'as' => 'subject-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/students',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Student\\StudentLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Student\\StudentLists',
        'namespace' => NULL,
        'prefix' => 'admin/students',
        'where' => 
        array (
        ),
        'as' => 'student-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-student-grade-components' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/students/view-{student_id}/schedule-{schedule_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Student\\MyGradeComponents\\MyGradeComponents@__invoke',
        'controller' => 'App\\Livewire\\Student\\MyGradeComponents\\MyGradeComponents',
        'namespace' => NULL,
        'prefix' => 'admin/students',
        'where' => 
        array (
        ),
        'as' => 'admin-student-grade-components',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/students/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Student\\AddStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Student\\AddStudent',
        'namespace' => NULL,
        'prefix' => 'admin/students',
        'where' => 
        array (
        ),
        'as' => 'student-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/students/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Student\\EditStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Student\\EditStudent',
        'namespace' => NULL,
        'prefix' => 'admin/students',
        'where' => 
        array (
        ),
        'as' => 'student-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/students/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Student\\DeleteStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Student\\DeleteStudent',
        'namespace' => NULL,
        'prefix' => 'admin/students',
        'where' => 
        array (
        ),
        'as' => 'student-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/students/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Student\\ActivateStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Student\\ActivateStudent',
        'namespace' => NULL,
        'prefix' => 'admin/students',
        'where' => 
        array (
        ),
        'as' => 'student-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/students/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Student\\ViewStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Student\\ViewStudent',
        'namespace' => NULL,
        'prefix' => 'admin/students',
        'where' => 
        array (
        ),
        'as' => 'student-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'room-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/rooms',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Room\\RoomLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Room\\RoomLists',
        'namespace' => NULL,
        'prefix' => 'admin/rooms',
        'where' => 
        array (
        ),
        'as' => 'room-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'room-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/rooms/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Room\\AddRoom@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Room\\AddRoom',
        'namespace' => NULL,
        'prefix' => 'admin/rooms',
        'where' => 
        array (
        ),
        'as' => 'room-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'room-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/rooms/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Room\\EditRoom@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Room\\EditRoom',
        'namespace' => NULL,
        'prefix' => 'admin/rooms',
        'where' => 
        array (
        ),
        'as' => 'room-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'room-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/rooms/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Room\\DeleteRoom@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Room\\DeleteRoom',
        'namespace' => NULL,
        'prefix' => 'admin/rooms',
        'where' => 
        array (
        ),
        'as' => 'room-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'room-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/rooms/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Room\\ActivateRoom@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Room\\ActivateRoom',
        'namespace' => NULL,
        'prefix' => 'admin/rooms',
        'where' => 
        array (
        ),
        'as' => 'room-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'room-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/rooms/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Room\\ViewRoom@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Room\\ViewRoom',
        'namespace' => NULL,
        'prefix' => 'admin/rooms',
        'where' => 
        array (
        ),
        'as' => 'room-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/admins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Admin\\AdminLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Admin\\AdminLists',
        'namespace' => NULL,
        'prefix' => 'admin/admins',
        'where' => 
        array (
        ),
        'as' => 'admin-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/admins/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Admin\\AddAdmin@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Admin\\AddAdmin',
        'namespace' => NULL,
        'prefix' => 'admin/admins',
        'where' => 
        array (
        ),
        'as' => 'admin-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/admins/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Admin\\EditAdmin@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Admin\\EditAdmin',
        'namespace' => NULL,
        'prefix' => 'admin/admins',
        'where' => 
        array (
        ),
        'as' => 'admin-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/admins/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Admin\\DeleteAdmin@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Admin\\DeleteAdmin',
        'namespace' => NULL,
        'prefix' => 'admin/admins',
        'where' => 
        array (
        ),
        'as' => 'admin-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/admins/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Admin\\ViewAdmin@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Admin\\ViewAdmin',
        'namespace' => NULL,
        'prefix' => 'admin/admins',
        'where' => 
        array (
        ),
        'as' => 'admin-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Faculty\\FacultyLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Faculty\\FacultyLists',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty',
        'where' => 
        array (
        ),
        'as' => 'faculty-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Faculty\\AddFaculty@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Faculty\\AddFaculty',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty',
        'where' => 
        array (
        ),
        'as' => 'faculty-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Faculty\\EditFaculty@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Faculty\\EditFaculty',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty',
        'where' => 
        array (
        ),
        'as' => 'faculty-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Faculty\\DeleteFaculty@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Faculty\\DeleteFaculty',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty',
        'where' => 
        array (
        ),
        'as' => 'faculty-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Faculty\\ActivateFaculty@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Faculty\\ActivateFaculty',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty',
        'where' => 
        array (
        ),
        'as' => 'faculty-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Faculty\\ViewFaculty@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Faculty\\ViewFaculty',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty',
        'where' => 
        array (
        ),
        'as' => 'faculty-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-type-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty-types',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyType\\FacultyTypeLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyType\\FacultyTypeLists',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty-types',
        'where' => 
        array (
        ),
        'as' => 'faculty-type-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-type-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty-types/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyType\\AddFacultyType@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyType\\AddFacultyType',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty-types',
        'where' => 
        array (
        ),
        'as' => 'faculty-type-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-type-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty-types/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyType\\EditFacultyType@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyType\\EditFacultyType',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty-types',
        'where' => 
        array (
        ),
        'as' => 'faculty-type-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-type-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty-types/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyType\\DeleteFacultyType@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyType\\DeleteFacultyType',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty-types',
        'where' => 
        array (
        ),
        'as' => 'faculty-type-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-type-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty-types/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyType\\ActivateFacultyType@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyType\\ActivateFacultyType',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty-types',
        'where' => 
        array (
        ),
        'as' => 'faculty-type-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-type-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/faculty-types/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyType\\ViewFacultyType@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyType\\ViewFacultyType',
        'namespace' => NULL,
        'prefix' => 'admin/academic/faculty-types',
        'where' => 
        array (
        ),
        'as' => 'faculty-type-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rank-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/ranks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Rank\\RankLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Rank\\RankLists',
        'namespace' => NULL,
        'prefix' => 'admin/academic/ranks',
        'where' => 
        array (
        ),
        'as' => 'rank-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rank-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/ranks/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Rank\\AddRank@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Rank\\AddRank',
        'namespace' => NULL,
        'prefix' => 'admin/academic/ranks',
        'where' => 
        array (
        ),
        'as' => 'rank-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rank-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/ranks/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Rank\\EditRank@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Rank\\EditRank',
        'namespace' => NULL,
        'prefix' => 'admin/academic/ranks',
        'where' => 
        array (
        ),
        'as' => 'rank-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rank-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/ranks/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Rank\\DeleteRank@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Rank\\DeleteRank',
        'namespace' => NULL,
        'prefix' => 'admin/academic/ranks',
        'where' => 
        array (
        ),
        'as' => 'rank-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rank-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/ranks/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Rank\\ActivateRank@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Rank\\ActivateRank',
        'namespace' => NULL,
        'prefix' => 'admin/academic/ranks',
        'where' => 
        array (
        ),
        'as' => 'rank-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rank-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/ranks/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Rank\\ViewRank@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Rank\\ViewRank',
        'namespace' => NULL,
        'prefix' => 'admin/academic/ranks',
        'where' => 
        array (
        ),
        'as' => 'rank-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'designation-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/designations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Designation\\DesignationLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Designation\\DesignationLists',
        'namespace' => NULL,
        'prefix' => 'admin/academic/designations',
        'where' => 
        array (
        ),
        'as' => 'designation-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'designation-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/designations/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Designation\\AddDesignation@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Designation\\AddDesignation',
        'namespace' => NULL,
        'prefix' => 'admin/academic/designations',
        'where' => 
        array (
        ),
        'as' => 'designation-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'designation-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/designations/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Designation\\EditDesignation@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Designation\\EditDesignation',
        'namespace' => NULL,
        'prefix' => 'admin/academic/designations',
        'where' => 
        array (
        ),
        'as' => 'designation-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'designation-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/designations/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Designation\\DeleteDesignation@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Designation\\DeleteDesignation',
        'namespace' => NULL,
        'prefix' => 'admin/academic/designations',
        'where' => 
        array (
        ),
        'as' => 'designation-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'designation-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/designations/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Designation\\ActivateDesignation@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Designation\\ActivateDesignation',
        'namespace' => NULL,
        'prefix' => 'admin/academic/designations',
        'where' => 
        array (
        ),
        'as' => 'designation-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'designation-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/academic/designations/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Designation\\ViewDesignation@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Designation\\ViewDesignation',
        'namespace' => NULL,
        'prefix' => 'admin/academic/designations',
        'where' => 
        array (
        ),
        'as' => 'designation-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'curriculum-lists-enrolled' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/curriculums/{college}/{department}/{curriculum_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Curriculum\\CurriculumProspectus@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Curriculum\\CurriculumProspectus',
        'namespace' => NULL,
        'prefix' => 'admin/curriculums',
        'where' => 
        array (
        ),
        'as' => 'curriculum-lists-enrolled',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'curriculum-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/curriculums/{college}/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Curriculum\\CurriculumLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Curriculum\\CurriculumLists',
        'namespace' => NULL,
        'prefix' => 'admin/curriculums',
        'where' => 
        array (
        ),
        'as' => 'curriculum-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'curriculum-lists-departments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/curriculums/{college}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Curriculum\\CurriculumDepartments@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Curriculum\\CurriculumDepartments',
        'namespace' => NULL,
        'prefix' => 'admin/curriculums',
        'where' => 
        array (
        ),
        'as' => 'curriculum-lists-departments',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'curriculum-lists-college' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/curriculums',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Curriculum\\CurriculumColleges@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Curriculum\\CurriculumColleges',
        'namespace' => NULL,
        'prefix' => 'admin/curriculums',
        'where' => 
        array (
        ),
        'as' => 'curriculum-lists-college',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scheduling-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingLists',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'scheduling-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'attendance-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/evaluation-{schedule_id}/attendance-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Evaluation\\AttendanceLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Evaluation\\AttendanceLists',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'attendance-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'evaluation-lists-final-grading' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/evaluation-final-grading-{schedule_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Evaluation\\EvaluationFinalGradingLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Evaluation\\EvaluationFinalGradingLists',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'evaluation-lists-final-grading',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'evaluation-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/evaluation-{schedule_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Evaluation\\EvaluationLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Evaluation\\EvaluationLists',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'evaluation-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'enrolled-student-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/enrolled-{schedule_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\EnrolledStudent\\EnrolledStudentLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\EnrolledStudent\\EnrolledStudentLists',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'enrolled-student-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'enrolled-student-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/enrolled-{schedule_id}/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\EnrolledStudent\\AddEnrolledStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\EnrolledStudent\\AddEnrolledStudent',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'enrolled-student-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'enrolled-student-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/enrolled-{schedule_id}/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\EnrolledStudent\\EditEnrolledStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\EnrolledStudent\\EditEnrolledStudent',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'enrolled-student-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'enrolled-student-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/enrolled-{schedule_id}/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\EnrolledStudent\\DeleteEnrolledStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\EnrolledStudent\\DeleteEnrolledStudent',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'enrolled-student-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'enrolled-student-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/enrolled-{schedule_id}/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\EnrolledStudent\\ActivateEnrolledStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\EnrolledStudent\\ActivateEnrolledStudent',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'enrolled-student-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'enrolled-student-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/enrolled-{schedule_id}/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\EnrolledStudent\\ViewEnrolledStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\EnrolledStudent\\ViewEnrolledStudent',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'enrolled-student-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'curriculum-subjects-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/{school_year}/{college}/{department}/{year_level}/{semester}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingSubjects@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingSubjects',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'curriculum-subjects-list',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scheduling-lists-enrolled' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/{school_year}/{college}/{department}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingEnrolled@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingEnrolled',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'scheduling-lists-enrolled',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scheduling-lists-departments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/{school_year}/{college}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingDepartments@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingDepartments',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'scheduling-lists-departments',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'scheduling-lists-college' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faculty-and-scheduling/{school_year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingColleges@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyAndScheduling\\FacultyAndSchedulingColleges',
        'namespace' => NULL,
        'prefix' => 'admin/faculty-and-scheduling',
        'where' => 
        array (
        ),
        'as' => 'scheduling-lists-college',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'schedule-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/schedules',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Schedule\\ScheduleLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Schedule\\ScheduleLists',
        'namespace' => NULL,
        'prefix' => 'admin/schedules',
        'where' => 
        array (
        ),
        'as' => 'schedule-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'schedule-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/schedules/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Schedule\\AddSchedule@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Schedule\\AddSchedule',
        'namespace' => NULL,
        'prefix' => 'admin/schedules',
        'where' => 
        array (
        ),
        'as' => 'schedule-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'schedule-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/schedules/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Schedule\\EditSchedule@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Schedule\\EditSchedule',
        'namespace' => NULL,
        'prefix' => 'admin/schedules',
        'where' => 
        array (
        ),
        'as' => 'schedule-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'schedule-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/schedules/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Schedule\\DeleteSchedule@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Schedule\\DeleteSchedule',
        'namespace' => NULL,
        'prefix' => 'admin/schedules',
        'where' => 
        array (
        ),
        'as' => 'schedule-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'schedule-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/schedules/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Schedule\\ActivateSchedule@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Schedule\\ActivateSchedule',
        'namespace' => NULL,
        'prefix' => 'admin/schedules',
        'where' => 
        array (
        ),
        'as' => 'schedule-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'schedule-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/schedules/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\Schedule\\ViewSchedule@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Schedule\\ViewSchedule',
        'namespace' => NULL,
        'prefix' => 'admin/schedules',
        'where' => 
        array (
        ),
        'as' => 'schedule-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'grade-equivalent-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/grade-equivalent',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\GradeEquivalent\\GradeEquivalentLists@__invoke',
        'controller' => 'App\\Livewire\\Admin\\GradeEquivalent\\GradeEquivalentLists',
        'namespace' => NULL,
        'prefix' => 'admin/grade-equivalent',
        'where' => 
        array (
        ),
        'as' => 'grade-equivalent-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'grade-equivalent-add' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/grade-equivalent/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\GradeEquivalent\\AddGradeEquivalent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\GradeEquivalent\\AddGradeEquivalent',
        'namespace' => NULL,
        'prefix' => 'admin/grade-equivalent',
        'where' => 
        array (
        ),
        'as' => 'grade-equivalent-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'grade-equivalent-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/grade-equivalent/edit-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\GradeEquivalent\\EditGradeEquivalent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\GradeEquivalent\\EditGradeEquivalent',
        'namespace' => NULL,
        'prefix' => 'admin/grade-equivalent',
        'where' => 
        array (
        ),
        'as' => 'grade-equivalent-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'grade-equivalent-delete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/grade-equivalent/delete-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\GradeEquivalent\\DeleteGradeEquivalent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\GradeEquivalent\\DeleteGradeEquivalent',
        'namespace' => NULL,
        'prefix' => 'admin/grade-equivalent',
        'where' => 
        array (
        ),
        'as' => 'grade-equivalent-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'grade-equivalent-activate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/grade-equivalent/activate-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\GradeEquivalent\\ActivateGradeEquivalent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\GradeEquivalent\\ActivateGradeEquivalent',
        'namespace' => NULL,
        'prefix' => 'admin/grade-equivalent',
        'where' => 
        array (
        ),
        'as' => 'grade-equivalent-activate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'grade-equivalent-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/grade-equivalent/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsAdmin',
        ),
        'uses' => 'App\\Livewire\\Admin\\GradeEquivalent\\ViewGradeEquivalent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\GradeEquivalent\\ViewGradeEquivalent',
        'namespace' => NULL,
        'prefix' => 'admin/grade-equivalent',
        'where' => 
        array (
        ),
        'as' => 'grade-equivalent-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-schedule-default' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:73:"function (){return \\redirect (\\route(\'my-schedule-school-years-lists\'));}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007350000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'my-schedule-default',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-schedule-school-years-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/my-schedules',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Faculty\\MySchedules\\MyScheduleShoolYears@__invoke',
        'controller' => 'App\\Livewire\\Faculty\\MySchedules\\MyScheduleShoolYears',
        'namespace' => NULL,
        'prefix' => 'faculty/my-schedules',
        'where' => 
        array (
        ),
        'as' => 'my-schedule-school-years-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-schedule-semesters-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/my-schedules/{school_year}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Faculty\\MySchedules\\MyScheduleSemesters@__invoke',
        'controller' => 'App\\Livewire\\Faculty\\MySchedules\\MyScheduleSemesters',
        'namespace' => NULL,
        'prefix' => 'faculty/my-schedules/{school_year}',
        'where' => 
        array (
        ),
        'as' => 'my-schedule-semesters-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-enrolled-students' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/my-schedules/{school_year}/{semester}/enrolled-students-{schedule_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Faculty\\EnrolledStudent\\EnrolledStudentLists@__invoke',
        'controller' => 'App\\Livewire\\Faculty\\EnrolledStudent\\EnrolledStudentLists',
        'namespace' => NULL,
        'prefix' => 'faculty/my-schedules/{school_year}/{semester}',
        'where' => 
        array (
        ),
        'as' => 'my-enrolled-students',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-evaluation-lists-final-grading' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/my-schedules/{school_year}/{semester}/evaluation-final-grading-{schedule_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Faculty\\FacultyEvaluation\\EvaluationFinalGradingLists@__invoke',
        'controller' => 'App\\Livewire\\Faculty\\FacultyEvaluation\\EvaluationFinalGradingLists',
        'namespace' => NULL,
        'prefix' => 'faculty/my-schedules/{school_year}/{semester}',
        'where' => 
        array (
        ),
        'as' => 'my-evaluation-lists-final-grading',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-attendance-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/my-schedules/{school_year}/{semester}/evaluation-{schedule_id}/attendance-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Faculty\\FacultyEvaluation\\AttendanceLists@__invoke',
        'controller' => 'App\\Livewire\\Faculty\\FacultyEvaluation\\AttendanceLists',
        'namespace' => NULL,
        'prefix' => 'faculty/my-schedules/{school_year}/{semester}',
        'where' => 
        array (
        ),
        'as' => 'my-attendance-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-evaluation-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/my-schedules/{school_year}/{semester}/evaluation-{schedule_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Faculty\\FacultyEvaluation\\FacultyEvaluationLists@__invoke',
        'controller' => 'App\\Livewire\\Faculty\\FacultyEvaluation\\FacultyEvaluationLists',
        'namespace' => NULL,
        'prefix' => 'faculty/my-schedules/{school_year}/{semester}',
        'where' => 
        array (
        ),
        'as' => 'my-evaluation-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-schedule-lists' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/my-schedules/{school_year}/{semester}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Faculty\\MySchedules\\MyScheduleLists@__invoke',
        'controller' => 'App\\Livewire\\Faculty\\MySchedules\\MyScheduleLists',
        'namespace' => NULL,
        'prefix' => 'faculty/my-schedules/{school_year}/{semester}',
        'where' => 
        array (
        ),
        'as' => 'my-schedule-lists',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-room-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/rooms/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Admin\\Room\\ViewRoom@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Room\\ViewRoom',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'my-room-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-subject-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/subjects/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Admin\\Subjects\\ViewSubject@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Subjects\\ViewSubject',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'my-subject-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-year-level-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/year-levels/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Admin\\YearLevel\\ViewYearLevel@__invoke',
        'controller' => 'App\\Livewire\\Admin\\YearLevel\\ViewYearLevel',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'my-year-level-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-semester-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/semesters/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Admin\\Semester\\ViewSemester@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Semester\\ViewSemester',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'my-semester-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-school-year-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/school-years/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Admin\\SchoolYear\\ViewSchoolYear@__invoke',
        'controller' => 'App\\Livewire\\Admin\\SchoolYear\\ViewSchoolYear',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'my-school-year-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-department-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/departments/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Admin\\Department\\ViewDepartment@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Department\\ViewDepartment',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'my-department-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-college-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/colleges/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Admin\\College\\ViewCollege@__invoke',
        'controller' => 'App\\Livewire\\Admin\\College\\ViewCollege',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'my-college-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-student-grade-components' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/students/view-{student_id}/schedule-{schedule_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Student\\MyGradeComponents\\MyGradeComponents@__invoke',
        'controller' => 'App\\Livewire\\Student\\MyGradeComponents\\MyGradeComponents',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'faculty-student-grade-components',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-student-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/students/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
        ),
        'uses' => 'App\\Livewire\\Admin\\Student\\ViewStudent@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Student\\ViewStudent',
        'namespace' => NULL,
        'prefix' => '/faculty',
        'where' => 
        array (
        ),
        'as' => 'faculty-student-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-designation-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/academic/designations/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
          4 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Admin\\Designation\\ViewDesignation@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Designation\\ViewDesignation',
        'namespace' => NULL,
        'prefix' => 'faculty/academic',
        'where' => 
        array (
        ),
        'as' => 'faculty-designation-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-rank-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/academic/ranks/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
          4 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Admin\\Rank\\ViewRank@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Rank\\ViewRank',
        'namespace' => NULL,
        'prefix' => 'faculty/academic',
        'where' => 
        array (
        ),
        'as' => 'faculty-rank-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-faculty-type-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/academic/faculty-types/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
          4 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Admin\\FacultyType\\ViewFacultyType@__invoke',
        'controller' => 'App\\Livewire\\Admin\\FacultyType\\ViewFacultyType',
        'namespace' => NULL,
        'prefix' => 'faculty/academic',
        'where' => 
        array (
        ),
        'as' => 'faculty-faculty-type-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'faculty-faculty-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'faculty/academic/faculty/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsFaculty',
          4 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Admin\\Faculty\\ViewFaculty@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Faculty\\ViewFaculty',
        'namespace' => NULL,
        'prefix' => 'faculty/academic',
        'where' => 
        array (
        ),
        'as' => 'faculty-faculty-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin-profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
        ),
        'uses' => 'App\\Livewire\\Admin\\Profile\\Profile@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Profile\\Profile',
        'namespace' => NULL,
        'prefix' => '/profile',
        'where' => 
        array (
        ),
        'as' => 'admin-profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-grades-default' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'student',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:52:"function (){return \\redirect (\\route(\'my-grades\'));}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007b50000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/student',
        'where' => 
        array (
        ),
        'as' => 'my-grades-default',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-grade-components' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'student/my-grades/view-{student_id}/schedule-{schedule_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Student\\MyGradeComponents\\MyGradeComponents@__invoke',
        'controller' => 'App\\Livewire\\Student\\MyGradeComponents\\MyGradeComponents',
        'namespace' => NULL,
        'prefix' => '/student',
        'where' => 
        array (
        ),
        'as' => 'student-grade-components',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-grades' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'student/my-grades',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Student\\MyGrades\\MyGrades@__invoke',
        'controller' => 'App\\Livewire\\Student\\MyGrades\\MyGrades',
        'namespace' => NULL,
        'prefix' => '/student',
        'where' => 
        array (
        ),
        'as' => 'my-grades',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'my-schedules' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'student/my-schedules',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Student\\MySchedules\\MySchedules@__invoke',
        'controller' => 'App\\Livewire\\Student\\MySchedules\\MySchedules',
        'namespace' => NULL,
        'prefix' => '/student',
        'where' => 
        array (
        ),
        'as' => 'my-schedules',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-room-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'student/rooms/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Admin\\Room\\ViewRoom@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Room\\ViewRoom',
        'namespace' => NULL,
        'prefix' => '/student',
        'where' => 
        array (
        ),
        'as' => 'student-room-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-subject-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'student/subjects/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Admin\\Subjects\\ViewSubject@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Subjects\\ViewSubject',
        'namespace' => NULL,
        'prefix' => '/student',
        'where' => 
        array (
        ),
        'as' => 'student-subject-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'student-faculty-view' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'student/faculty/view-{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
          3 => 'App\\Http\\Middleware\\IsStudent',
        ),
        'uses' => 'App\\Livewire\\Admin\\Faculty\\ViewFaculty@__invoke',
        'controller' => 'App\\Livewire\\Admin\\Faculty\\ViewFaculty',
        'namespace' => NULL,
        'prefix' => '/student',
        'where' => 
        array (
        ),
        'as' => 'student-faculty-view',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'attendance-dates' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/attendance-dates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
        ),
        'uses' => 'App\\Http\\Controllers\\AttendanceController@attendance_dates',
        'controller' => 'App\\Http\\Controllers\\AttendanceController@attendance_dates',
        'namespace' => NULL,
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'attendance-dates',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'attendance-dates-remove' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/attendance-dates/remove',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
        ),
        'uses' => 'App\\Http\\Controllers\\AttendanceController@remove_attendace_date',
        'controller' => 'App\\Http\\Controllers\\AttendanceController@remove_attendace_date',
        'namespace' => NULL,
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'attendance-dates-remove',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'attendance-dates-add' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/attendance-dates/add',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\IsAuthenticated',
          2 => 'App\\Http\\Middleware\\IsValid',
        ),
        'uses' => 'App\\Http\\Controllers\\AttendanceController@add_attendace_date',
        'controller' => 'App\\Http\\Controllers\\AttendanceController@add_attendace_date',
        'namespace' => NULL,
        'prefix' => '/api',
        'where' => 
        array (
        ),
        'as' => 'attendance-dates-add',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:81:"/home/u701207055/domains/wmsugradingsystem.online/public_html/storage/app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:1;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000007280000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
